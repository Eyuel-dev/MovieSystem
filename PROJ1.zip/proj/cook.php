<?php
echo $_COOKIE["id"];
?>