<?php 
require("start.php");
if(isset($_SESSION['username'])){
    header("Location: home.php");
}else{
$email = "";
$pass = "";
?>
<html>
<head>
	<title>Registration Form</title>

   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css">    

	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>
	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
	
   <header class="main-header">
   	
   	<div class="logo">
	      <a href="home.php">Elevate</a>
	   </div> 

<a class="menu-toggle" href="home.php"><span>Menu</span></a>   	

   </header>

   <nav id="menu-nav-wrap">

        <h3>Navigation</h3>   	
         <ul class="nav-list">
             <li><a href="home.php" title="">Home</a></li>
             <li><a href="register.php" title="">Register</a></li>
			 <li><a href="login.php" title="">Login</a></li>
			 <li><a href="videos.php" title="">Explore</a></li>
			 <li><a href="reqest.php" title="">Reqest</a></li>	
			 <li><a href="person.php" title="">Account Information</a></li>		
         </ul>
     </nav> 


		<section id="pricing">

	   	<div class="row section-intro animate-this">
	   		<div class="col-twelve with-bottom-line">

	   			<h2>JOIN US</h2>

	   			<p class="lead">And Get The Best Movies , Series , Documnary And Many More. With Our Deleveray Service You Do Not Have To Worry About Finding Us.</p>

	   		</div>   		
	   	</div>
     <form action="regwelcome.php" method="POST">
	   	<div class="row pricing-content">

	         <div class="pricing-tables block-1-3  group">

	            <div class="bgrid animate-this"> 

	            	<div class="price-block">

	            		<div class="top-part">

		            		<h3 class="plan-title">ADDRESS INFORMATION FORM</h3>
			               	             

		            	</div>               

		               <div class="bottom-part">

		            		<ul class="features">
			                  <li><select name="kk">
							  <option selected="select">KEFLE KETEMA</option>
							  <option value="yeka">YEKA</option>
							  <option value="bole">BOLE</option>
							  <option value="lafto">LAFTO</option>
							  <option value="kolfe">KOLFE</option>
							  <option value="kality">AKAKE KALITY</option>
							  </li>		                  
			                  <li><input type="text"  placeholder="WOREDA" name="woreda"></li>		                  
                              <li><input type="text"  placeholder="HOUSE NUMBER" name="hno"></li>
                              <li><input type="text" placeholder="E-MAIL" name="email"></li>
                              
			               </ul>

			               

		            	</div>

	            	</div>           	
	                        
				   </div> 

	            <div class="bgrid animate-this">

	            	<div class="price-block">

	            		<div class="top-part">

		            		<h3 class="plan-title">ACCOUNT INFORMATION FORM</h3>
			            							

		            	</div>               

		               <div class="bottom-part">

		            		<ul class="features">
							  <li><input type="text"  placeholder="USERNAME" name="uname"></li>
							
			                  <li><input type="text"  placeholder="PASSWORD" name="pword"></li>		                  
			                  		                  
			                  
			               </ul>

						  <input type="submit" class="button large" value="regester" name="submit">
						  
						
					</br>
                          <a class="button large" href="register.php">clear</a>
		            	</div>
	            		<p class="plan-title"></br>
                         </p>
	            	</div>            	                 

				  </div> 

	           <div class="bgrid animate-this">               

	               <div class="price-block">

	            		<div class="top-part">

		            		<h3 class="plan-title">PERSONAL INFORMATION FORM</h3>	                		               

		            	</div> 
		            	
							<div class="bottom-part">

		            		<ul class="features">
			                  <li><input type="text" placeholder="FIRST NAME" name="fname"></li>
			                  <li><input type="text" placeholder="LAST NAME" name="lname"></li>		                  
                              <li><input type="text" placeholder="CELLPHONE" name="cellno"></li>
                              <li><input type="text"  placeholder="BALANCE" name="bal"></li>		                  
			                  
			               </ul>
		            	</div>	            		                
	            		
	            	</div>                              

				   </div> 	           

	         </div> 

	      </div> 
  </form>
	   </section> 
	   <?php include "foot.php"?>
   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

 </body>

</html>

<?php
}
?>