<?php
require("link.php");
?>
<html>
<head>
<script>
function myFunction(a) {
    document.getElementById(a).innerHTML = ":Rented";
    
}
</script>

<title>VIDEOS</title>

<link rel="stylesheet" href="css/basee.css">
<link rel="stylesheet" href="css/img.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/screen.css">
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />
<link rel="icon" href="images/fpic.jpg">

</head>
<body>
<form action="rent.php" method="POST">

<div class="blankSeparator"></div>
<div class="container portfolio4columns">
  
    <h1 align="center">EXPLORE OUR OPTIONS</h1>
  <ul class="tabs">
    <li><a class="active" href="#beauty">MOVIE</a></li>
    <li><a href="#woman">STANDUP</a></li>
    <li><a href="#people">DOCUMENTARY</a></li>
    <li><a href="home.php">HOME</a></li>
  </ul>
  <div class="sepContainer1"></div>
  <ul class="tabs-content clearfix">


    <li class="active clearfix" id="beauty">
      
            <div class="container">
                    
                    <h2>MOVIES</h2>
                    <?php
                  $x=2;
$query = "SELECT * FROM video WHERE v_type ='movie' ";
$query_res = mysqli_query($con,$query);
if($query_res){
  
    while($data = mysqli_fetch_assoc($query_res)){
        $name = $data["v_name"];
        $id = $data["v_id"];
        $x++;
       echo '
    <div class="toggle-trigger">'.$name.'</div>
    <div class="toggle-container">
    <img id="myImg"  src='.$data["img1"].'>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img id="myImg" src='.$data["img2"].'>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img  id="myImg" src='.$data["img3"].'>
    
      <p>Descreption : '.$data["v_decription"].'</p>
      <p>Rating : '.$data["v_rating"].'</p>
      <p>Price : '.$data["v_price"].' Birr</p>
      <input type="hidden" value=" '.$id.'">
      <div><p id='.$x.' style="color:black; font-size:22px; margin-bottom:-30px;margin-left:50px;">:Rent</p>
      <label class="switch">
      <input type="checkbox" name="ids[]" value='.$id.' onclick="myFunction('.$x.')">
      <div class="slider"></div>
    </label>
    </div>
    </div>
    ';
    }
}
?>                 
   </div>
     <div class="blankSeparator1"></div>
                  
      <div class="clear"></div>
    </li>

    <li id="woman" class="clearfix">

            <div class="container">
                  <h2>STANDUPS</h2>
                  
                    <?php

$query = "SELECT * FROM video WHERE v_type ='stdup' ";
$query_res = mysqli_query($con,$query);
if($query_res){
    while($data = mysqli_fetch_assoc($query_res)){
        $name = $data["v_name"];
        $id = $data["v_id"];
        $x++;
       echo '
    <div class="toggle-trigger">'.$name.'</div>
    <div class="toggle-container">
    <img  id="myImg" src='.$data["img1"].'>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src='.$data["img2"].' id="myImg">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src='.$data["img3"].' id="myImg">
    <p>Descreption : '.$data["v_decription"].'</p>
      <p>Rating : '.$data["v_rating"].'</p>
      <p>Price : '.$data["v_price"].' Birr</p>
      <input type="hidden" value=" '.$id.'">
      <div><p id='.$x.' style="color:black; font-size:22px; margin-bottom:-30px;margin-left:50px;">:Rent</p>
      <label class="switch">
      <input type="checkbox" name="ids[]" value='.$id.' onclick="myFunction('.$x.')">
      <div class="slider"></div>
    </label>
    </div>
    </div>
    ';
    }
}
?>

  </div>
                  
  <div class="blankSeparator1"></div>
                  
        

      <div class="clear"></div>
    </li>

   <li id="people" class="clearfix">

            <div class="container">
                    <h2>DOCUMENTARIES</h2>


                    <?php
$query = "SELECT * FROM video WHERE v_type ='documentary' ";
$query_res = mysqli_query($con,$query);
if($query_res){
    while($data = mysqli_fetch_assoc($query_res)){
        $name = $data["v_name"];
        $id = $data["v_id"];
        $x++;
       echo '
    <div class="toggle-trigger">'.$name.'</div>
    <div class="toggle-container">
    <img src='.$data["img1"].' id="myImg">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src='.$data["img2"].' id="myImg">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src='.$data["img3"].' id="myImg">
    <p>Descreption : '.$data["v_decription"].'</p>
      <p>Rating : '.$data["v_rating"].'</p>
      <p>Price : '.$data["v_price"].' Birr</p>
      <input type="hidden" value=" '.$id.'">
     <div><p id='.$x.' style="color:black; font-size:22px; margin-bottom:-30px;margin-left:50px;">:Rent</p>
      <label class="switch">
      <input type="checkbox" name="ids[]" value='.$id.' onclick="myFunction('.$x.')">
      <div class="slider"></div>
    </label>
    </div>
    </div>
    ';
    }
}
?>
 </div> 
  <div class="blankSeparator1"></div>
                  

      <div class="clear"></div>
    </li>
</ul>
  
  
</div>
<input type="submit" class="sub" value="DONE">
</form>

<div>
<div class="sepContainer1"></div>
<?php
require("start.php");
if(isset($_SESSION['username'])){
  echo "<a href='logou.php' style='
  color:#fffa;
  font-size:15px;
  font-family:montserrat;
  border: 1px solid #3498db;
  background:grey;
  margin-left:1000px;
  padding:5px;
  align:left;
  '>Log Out</a>
  ";
}
if(!isset($_SESSION['username'])){
echo"
<a href='login.php' style='
color:#fffa;
font-size:15px;
font-family:montserrat;
border: 1px solid #3498db;
background:grey;
margin-left:1000px;
padding:5px;
text-align:center;
'>Log in</a>
";
}
?>
</div>
<div class="blankSeparator1"></div>
<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
<script src="js/screen.js" type="text/javascript"></script> 
<script src="js/poshytip-1.0/src/jquery.poshytip.min.js" type="text/javascript"></script> 
<script src="js/tabs.js" type="text/javascript"></script> 
<script src="js/jquery.tweetable.js" type="text/javascript"></script> 
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<script src="js/superfish.js" type="text/javascript"></script> 
<script src="js/hoverIntent.js" type="text/javascript"></script> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>
</body>
</html>