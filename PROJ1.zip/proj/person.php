
<?php include "link.php";
require("start.php");
?>
<head>
	<title>ACCOUNT INFORMATION</title>

   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css">    
	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>
	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
   <header class="main-header">
   	
   	<div class="logo">
	      <a href="home.html">Elevate</a>
	   </div> 

	   <a class="menu-toggle" href="home.php"><span>Menu</span></a>   	

   </header>

  <nav id="menu-nav-wrap">

        <h3>Navigation</h3>   	
         <ul class="nav-list">
             <li><a href="home.php" title="">Home</a></li>
             <li><a href="register.php" title="">Register</a></li>
			 <li><a href="login.php" title="">Login</a></li>
			 <li><a href="videos.php" title="">Explore</a></li>	
             <li><a href="reqest.php" title="">Reqest</a></li>
             <li><a href="person.php" title="">Account Information</a></li>		
         </ul>
     </nav>
		<section id="pricing">

	   	<div class="row section-intro animate-this">
	   		<div class="col-twelve with-bottom-line">

	   			<h2>ACCOUNT INFORMATION</h2>

	   			<p class="lead">Seen Your Account Information , Check Your Balance And Enjoy Our Servies</p>

	   		</div>   		
	   	</div>

	   	<div class="row pricing-content">

	         <div class="pricing-tables block-1-3  group">

	            <div class="bgrid animate-this"> 

	            	          	
	                        
				   </div> 

	            <div class="bgrid animate-this">

	            	<div class="price-block">

	            		
                          <?php
                          if(isset($_SESSION['username'])){
                          $test=$_SESSION['username'];
                              if($test!=""){
                                  $id=$test;
                                  $mname="";
                                  $query = "SELECT * from member_user  where m_username='$id'";
                                  $query_res = mysqli_query($con,$query);
                                  
                                  while($data = mysqli_fetch_assoc($query_res)){
                                    $name = $data["m_fname"];
                                    $bal=$data["m_balance"];
                                  }                          
                                  echo'
                                  <div class="top-part">
                            <h3 class="plan-title">HELLO '.$name.'</h3>
			               <p class="price-month"> Balance='.$bal.' Birr</p>							
                        </div>  
                        
                                  ';

                                  $query1= "SELECT * from copy inner join video on copy.v_id=video.v_id  where c_rby='$id'";
                                  $query_res1 = mysqli_query($con,$query1);
                                  echo '<p class="price-month">Rented Movies</p>';
                                  while($data1 = mysqli_fetch_assoc($query_res1)){    
                                      $mname=$data1["v_name"];                  
                                  echo'
                                '.$mname.' </br>';}
                                  
                                  if($mname==""){
                                    echo'</br><p class="price-month">NO RENTED MOVIES</p>';
                                }
                           echo"</br><a class='button large' href='logou.php'>LOGOUT</a>"; 
                          }
                        }
                        if(!isset($_SESSION['username'])){
                    
                                echo "<h3 class='plan-title'>Sorry You Are Not Loged In</h3>
                                <a class='button large' href='login.php'>LOGIN</a>
                                ";
                            
                           
                        }
                          ?>             

	            		
	            	</div>            	                 

				  </div> 

	                     

	         </div> 

	      </div>

	   </section> 


	  <?php include "foot.php";?>

   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>