<?php 
    $us=rand(10000,99999);
    $pw=$_POST['message'];
    $fname=$_POST['cellno'];
    $lname=$_POST['email'];
    $conn = new mysqli("localhost", "root", "","project");
    $sql="insert into special_request(sr_id,sr_request,sr_cellphone,sr_email) values('$us','$pw','$fname','$lname')";
 if ($conn->query($sql) === TRUE) {
    echo "THANK YOU</br> OUR STAFF MEMBER WILL CONTACT YOU SOON";
  }
 else {
    echo "SORRY ERROR HAS OCCUED CHECK YOUR INPUT AND TRY AGAIN";
    echo "</br></br><a href='reqest.php'> |BACK|</a>";
   }
?>