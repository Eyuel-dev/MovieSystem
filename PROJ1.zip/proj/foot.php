 
   
	<footer id="main-footer">

   	<div class="footer-social-wrap">  
   		<div class="row">
					
	         <ul class="footer-social-list">
	            <li><a href="#">
	             	<i class="fa fa-facebook-square"></i>
	            </a></li>
	            <li><a href="#">
	              	<i class="fa fa-twitter"></i>
	            </a></li>
              <li><a href="#">
	              	<i class="fa fa-google-plus"></i>
	            </a></li>
	            <li><a href="#">
	              	<i class="fa fa-pinterest"></i>
	            </a></li>
	            <li><a href="#">
	              	<i class="fa fa-instagram"></i>
	            </a></li>
	            <li><a href="#">
	              	<i class="fa fa-dribbble"></i>
	            </a></li>
	         </ul>
		         
			</div> 
   	</div> 

	   <div class="footer-info-wrap">

	   	<div class="row footer-info">

		  		<div class="col-four tab-full">
		  			<h4><i class="icon-location-map-1"></i> Where to Find Us</h4>

		  			<p>
		         5-Killo<br>
		         ADISS ABABA UNIVERSITY, A.A<br>
		         ETHIOPIA
		         </p>
		  		</div>

		   	<div class="col-four tab-full collapse">
	   			<h4><i class="icon-phone-incoming"></i> Get In Touch</h4>

	   			<p>VIDEORENTAL.com<br>
				   	Phone: +251934540217			     
				   </p>
	   		</div>

	   		<div class="col-four tab-full">
	   			<h4><i class="icon-organization-hierarchy-3"></i> Company Links</h4>

				   <ul class="footer-link-list">
				   	<li><a href="login.php">LOGIN</a></li>
				   	<li><a href="videos.php">EXPLORE</a></li>
				   </ul>
	   		</div>
		   		
		  	</div>
	   </div> 
	   	
	   <div class="footer-bottom"> 

	   	<div class="copyright">
		     	<span>© Copyright TO OUR GROUP 2018/2019.</span> 
		     		         	
		   </div>  		
   	</div>
	   	
   </footer>   
