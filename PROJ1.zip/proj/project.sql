-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2019 at 12:49 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `copy`
--

CREATE TABLE `copy` (
  `c_id` varchar(5) NOT NULL,
  `c_renteddate` date NOT NULL,
  `v_id` varchar(5) DEFAULT NULL,
  `c_returneddate` date DEFAULT NULL,
  `c_status` varchar(15) NOT NULL,
  `c_rby` varchar(5) DEFAULT NULL,
  `c_rbynm` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `copy`
--

INSERT INTO `copy` (`c_id`, `c_renteddate`, `v_id`, `c_returneddate`, `c_status`, `c_rby`, `c_rbynm`) VALUES
('c001', '0000-00-00', 'v001', NULL, 'rented', 'sami11', NULL),
('c002', '0000-00-00', 'v001', NULL, 'rented', 'sami11', 38097),
('c003', '0000-00-00', 'v002', NULL, 'n_rented', NULL, NULL),
('c004', '0000-00-00', 'v002', NULL, 'n_rented', NULL, NULL),
('c005', '0000-00-00', 'v003', NULL, 'n_rented', NULL, NULL),
('c006', '0000-00-00', 'v003', NULL, 'n_rented', NULL, NULL),
('c007', '0000-00-00', 'v004', NULL, 'n_rented', NULL, NULL),
('c008', '0000-00-00', 'v004', NULL, 'n_rented', NULL, NULL),
('c009', '0000-00-00', 'v005', NULL, 'rented', 'sam77', NULL),
('c010', '0000-00-00', 'v005', NULL, 'n_rented', NULL, NULL),
('c011', '0000-00-00', 'v006', NULL, 'n_rented', NULL, NULL),
('c012', '0000-00-00', 'v006', NULL, 'n_rented', NULL, NULL),
('c013', '0000-00-00', 'v007', NULL, 'rented', NULL, 19278),
('c014', '0000-00-00', 'v007', NULL, 'rented', NULL, 87373),
('c015', '0000-00-00', 'v008', NULL, 'n_rented', NULL, NULL),
('c016', '0000-00-00', 'v009', NULL, 'n_rented', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_id` varchar(5) NOT NULL,
  `e_fname` varchar(15) NOT NULL,
  `e_lname` varchar(15) NOT NULL,
  `e_position` varchar(15) NOT NULL,
  `e_shift` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`e_id`, `e_fname`, `e_lname`, `e_position`, `e_shift`) VALUES
('e001', 'Haylemikael', 'tefera', 'reception', 'afternoon'),
('e002', 'Samson', 'Kassa', 'reception', 'morning');

-- --------------------------------------------------------

--
-- Table structure for table `member_user`
--

CREATE TABLE `member_user` (
  `m_username` varchar(15) NOT NULL,
  `m_password` varchar(15) NOT NULL,
  `m_fname` varchar(15) NOT NULL,
  `m_lname` varchar(15) NOT NULL,
  `m_kk` varchar(15) NOT NULL,
  `m_woreda` int(11) NOT NULL,
  `m_hno` int(11) NOT NULL,
  `m_email` varchar(15) NOT NULL,
  `m_cellphone` varchar(13) NOT NULL,
  `m_balance` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_user`
--

INSERT INTO `member_user` (`m_username`, `m_password`, `m_fname`, `m_lname`, `m_kk`, `m_woreda`, `m_hno`, `m_email`, `m_cellphone`, `m_balance`) VALUES
('miki', '12345678', 'haylemikael', 'tefera', '5-killo', 1, 000, 'haylemikaeltefera@gmail.com', '251934540217', 25),
('sami11', 'sami11', 'samson', 'kassa', '5-killo', 1, 000, 'samsonkassa25@gmail.com', '251916134415', 47),
('henock11', 'henock11', 'Henock', 'Yonas', '5-killo', 1, 000, 'henock@gmail.com', '251941000046', 30),
('eyuel11', 'eyuel11', 'Eyuel', 'Alemu', '5-killo', 1, 000, 'eyu@gmail.com', '251966217026', 50),
('yusra11', 'yusra11', 'Yusra', 'Ahmed', '5-killo', 1, 000, 'yusra@gmail.com.', '251955346696', 30);
-- --------------------------------------------------------

--
-- Table structure for table `nm_user`
--

CREATE TABLE `nm_user` (
  `n_id` int(5) NOT NULL,
  `e_id` varchar(5) DEFAULT NULL,
  `n_payment` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nm_user`
--

INSERT INTO `nm_user` (`n_id`, `e_id`, `n_payment`) VALUES
(19278, NULL, 7),
(38097, NULL, 3),
(48437, NULL, 3),
(74888, NULL, 0),
(76874, NULL, 0),
(86333, NULL, 0),
(87373, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `special_request`
--

CREATE TABLE `special_request` (
  `sr_id` int(5) NOT NULL,
  `sr_request` text NOT NULL,
  `sr_cellphone` varchar(13) NOT NULL,
  `sr_email` varchar(15) NOT NULL,
  `e_id` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_request`
--

INSERT INTO `special_request` (`sr_id`, `sr_request`, `sr_cellphone`, `sr_email`, `e_id`) VALUES
(24365, 'please add more copy', '251999999999', 'sami@gmail.com', NULL),
(69220, 'sss', '251999999999', 'sdf@sds.com', NULL),
(78026, 'regdf', '251999999999', 'sdf@sds.com', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `v_id` varchar(5) NOT NULL,
  `v_type` varchar(15) NOT NULL,
  `v_decription` text NOT NULL,
  `v_price` double NOT NULL,
  `v_rating` double NOT NULL,
  `v_name` varchar(100) NOT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`v_id`, `v_type`, `v_decription`, `v_price`, `v_rating`, `v_name`, `img1`, `img2`, `img3`) VALUES
('v001', 'movie', 'Venom is a 2018 American superhero film based on the Marvel Comics character of the same name, produced by Columbia Pictures in association with Marvel[5] and Tencent Pictures. Distributed by Sony Pictures Releasing, it is the first film in Sony\'s Marvel Universe, adjunct to the Marvel Cinematic Universe (MCU).[a] Directed by Ruben Fleischer from a screenplay by Scott Rosenberg, Jeff Pinkner, and Kelly Marcel, it stars Tom Hardy as Eddie Brock / Venom, alongside Michelle Williams, Riz Ahmed, Scott Haze, and Reid Scott. In Venom, journalist Brock gains superpowers after being bound to an alien symbiote whose species plans to invade Earth.\r\n\r\n', 3, 6.8, 'venom', 'images/movie/venom/1.jpg', 'images/movie/venom/2.jpg', 'images/movie/venom/3.jpg'),
('v002', 'movie', 'Mile 22 is a 2018 American espionage action thriller film directed by Peter Berg and written by Lea Carpenter, from a story by Carpenter and Graham Roland.[4] The film stars Mark Wahlberg, John Malkovich, Lauren Cohan, Iko Uwais, and Ronda Rousey. It follows an elite CIA task force composed of paramilitary officers from Ground Branch of Special Activities Division, that has to escort a high-priority asset 22 miles to an extraction point while being hunted by the government.[5][6] The film marks the fourth collaboration between Berg and Wahlberg, following Lone Survivor, Deepwater Horizon, and Patriots Day.', 4, 7.7, '22miles', 'images/movie/22/1.jpg', 'images/movie/22/2.jpg', 'images/movie/22/3.jpg'),
('v003', 'movie', 'Marvel\'s The Avengers[6] (classified under the name Marvel Avengers Assemble in the United Kingdom and Ireland),[3][7] or simply The Avengers, is a 2012 American superhero film based on the Marvel Comics superhero team of the same name, produced by Marvel Studios and distributed by Walt Disney Studios Motion Pictures.[N 1] It is the sixth film in the Marvel Cinematic Universe (MCU). The film was written and directed by Joss Whedon and features an ensemble cast that includes Robert Downey Jr., Chris Evans, Mark Ruffalo, Chris Hemsworth, Scarlett Johansson, and Jeremy Renner as the titular Avengers team, alongside Tom Hiddleston, Clark Gregg, Cobie Smulders, Stellan Skarsgård, and Samuel L. Jackson. In the film, Nick Fury, director of the spy agency S.H.I.E.L.D., recruits Tony Stark, Captain America, the Hulk, and Thor to form a team that must stop Thor\'s brother Loki from subjugating Earth.', 6, 9.8, 'avengers', 'images/movie/ave/1.jpg', 'images/movie/ave/2.jpg', 'images/movie/ave/3.jpg'),
('v004', 'movie', 'When We First Met is a 2018 American romantic comedy film directed by Ari Sandel, written by John Whittington and starring Adam DeVine, Alexandra Daddario, Shelley Hennig, Andrew Bachelor and Robbie Amell. It was released worldwide on Netflix on February 9, 2018.[1]', 3, 7.7, 'when we first met', 'images/movie/met/1.jpg', 'images/movie/met/2.jpg', 'images/movie/met/3.jpg'),
('v005', 'movie', 'Black Panther is a 2018 American superhero film based on the Marvel Comics character of the same name. Produced by Marvel Studios and distributed by Walt Disney Studios Motion Pictures, it is the eighteenth film in the Marvel Cinematic Universe (MCU). The film is directed by Ryan Coogler, who co-wrote the screenplay with Joe Robert Cole, and stars Chadwick Boseman as T\'Challa / Black Panther, alongside Michael B. Jordan, Lupita Nyong\'o, Danai Gurira, Martin Freeman, Daniel Kaluuya, Letitia Wright, Winston Duke, Angela Bassett, Forest Whitaker, and Andy Serkis. In Black Panther, T\'Challa is crowned king of Wakanda following his father\'s death, but his sovereignty is challenged by an adversary who plans to abandon the country\'s isolationist policies and begin a global revolution.', 4, 8.8, 'black panther', 'images/movie/black/1.jpg', 'images/movie/black/2.jpg', 'images/movie/black/3.jpg'),
('v006', 'documentary', 'Hunting Hitler is a History Channel television series based on the hypothetical premise that if Adolf Hitler escaped from the Führerbunker in Berlin at the end of World War II, how might he had done so and where might he have gone.[1] The show was conceived due to the recent declassification of FBI documents exploring whether Hitler might still be alive in the late 1940s.[2]', 3, 6.6, 'hunting hittler', 'images/docu/hittler/1.jpg', 'images/docu/hittler/2.jpg', 'images/docu/hittler/3.jpg'),
('v007', 'documentary', 'Putin was born in Leningrad during the Soviet Union. He studied law at Leningrad State University, graduating in 1975.[6] Putin was a KGB foreign intelligence officer for 16 years, rising to the rank of Lieutenant Colonel before resigning in 1991 to enter politics in Saint Petersburg. He moved to Moscow in 1996 and joined President Boris Yeltsin\'s administration, rising quickly through the ranks and becoming Acting President on 31 December 1999, when Yeltsin resigned.', 4, 7.7, 'Revenge of Putin', 'images/docu/putin/1.jpg', 'images/docu/putin/2.jpg', 'images/docu/putin/3.jpg'),
('v008', 'stdup', 'illiam Frederic Burr (born June 10, 1968) is an American stand-up comedian, actor, voice actor, writer, musician,[1] producer,[2] podcaster,[3] and social critic.[4] He has released six stand-up specials. Outside of stand-up, he is known for hosting the Monday Morning Podcast, appearing on Chappelle\'s Show, playing Patrick Kuby in the AMC crime drama series Breaking Bad, and creating and starring in the Netflix animated sitcom F Is for Family. He also co-founded the All Things Comedy network.', 2, 5.5, 'Bill Burr: You People Are All The Same', 'images/std/std1/1.jpg', 'images/std/std1/2.jpg', 'images/std/std1/3.jpg'),
('v009', 'stdup', 'Kevin Hart: What Now? is a 2016 American stand-up comedy concert film starring comedian Kevin Hart, based on his 2015 stand-up tour of the same name. It is the third theatrical release of a Hart stand-up show, following Kevin Hart: Laugh at My Pain (2011) and Kevin Hart: Let Me Explain (2013). The film was released in the United States on October 14, 2016. It received generally positive reviews and grossed $23 million.', 3, 5.5, 'What Now', 'images/std/std1/1.jpg', 'images/std/std1/2.jpg', 'images/std/std1/3.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `copy`
--
ALTER TABLE `copy`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `v_id` (`v_id`),
  ADD KEY `c_rby` (`c_rby`),
  ADD KEY `c_rbynm` (`c_rbynm`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `member_user`
--
ALTER TABLE `member_user`
  ADD PRIMARY KEY (`m_username`);

--
-- Indexes for table `nm_user`
--
ALTER TABLE `nm_user`
  ADD PRIMARY KEY (`n_id`),
  ADD KEY `e_id` (`e_id`);

--
-- Indexes for table `special_request`
--
ALTER TABLE `special_request`
  ADD PRIMARY KEY (`sr_id`),
  ADD KEY `e_id` (`e_id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`v_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `copy`
--
ALTER TABLE `copy`
  ADD CONSTRAINT `copy_ibfk_1` FOREIGN KEY (`v_id`) REFERENCES `video` (`v_id`),
  ADD CONSTRAINT `copy_ibfk_2` FOREIGN KEY (`c_rby`) REFERENCES `member_user` (`m_username`),
  ADD CONSTRAINT `copy_ibfk_3` FOREIGN KEY (`c_rby`) REFERENCES `member_user` (`m_username`),
  ADD CONSTRAINT `copy_ibfk_4` FOREIGN KEY (`c_rbynm`) REFERENCES `nm_user` (`n_id`);

--
-- Constraints for table `nm_user`
--
ALTER TABLE `nm_user`
  ADD CONSTRAINT `nm_user_ibfk_2` FOREIGN KEY (`e_id`) REFERENCES `employee` (`e_id`);

--
-- Constraints for table `special_request`
--
ALTER TABLE `special_request`
  ADD CONSTRAINT `special_request_ibfk_1` FOREIGN KEY (`e_id`) REFERENCES `employee` (`e_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
