<?php 
require("start.php");
if(isset($_SESSION['username'])){
    header("Location: home.php");
}else{
$email = "";
$pass = "";
?>

<head>
  <title>LOGIN</title>

   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css">    

	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>

	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
	
   <header class="main-header">
   	
   	<div class="logo">
	      <a href="home.php">Elevate</a>
	   </div> 

	   <a class="menu-toggle" href="#"><span>Menu</span></a>   	

   </header>

   <nav id="menu-nav-wrap">

        <h3>Navigation</h3>   	
         <ul class="nav-list">
             <li><a href="home.php" title="">Home</a></li>
             <li><a href="register.php" title="">Register</a></li>
			 <li><a href="login.php" title="">Login</a></li>
			 <li><a href="videos.php" title="">Explore</a></li>	
			 <li><a href="reqest.php" title="">Reqest</a></li>	
			 <li><a href="person.php" title="">Account Information</a></li>		
         </ul>
     </nav> 
		<section id="pricing">

	   	<div class="row section-intro animate-this">
	   		<div class="col-twelve with-bottom-line">

	   			<h2>LOGIN</h2>

	   		</div>   		
		   </div>
		   

		 <div class="row pricing-content">
		   <div class="pricing-tables block-1-3  group">
            <div class="bgrid animate-this"></div> 
			  <div class="bgrid animate-this">
				  <div class="price-block">
					  <div class="top-part"></div>               
					 <div class="bottom-part">
<p class="plan-title">
<?php
	if(isset($_POST['submit'])){
		$un=$_POST['uname'];
		$pw=$_POST['pword'];
		$email = $un;
		$pass = $pw;
		$cun="";
		$cpw="";
		$name="";
		$conn = new mysqli("localhost", "root", "","project");
		$sql="select m_username,m_password,m_fname from member_user  where m_username='$un'";
		$result = $conn->query($sql);
	  
	  if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			 $cun=$row["m_username"];
			 $cpw=$row["m_password"];
			 $name=$row["m_fname"];
			 
		}
	  } 
	  if($cun==""){
		  
        echo "UNKNOWN USER";
        echo'
        <p class="plan-title"><a class="button large" href="login.php">BACK</a></br></p>';
			 
	  }
	  if($cun==$un){
	  
		if($cpw==$pw)
		{
		
			$_SESSION['username'] = $cun;
			echo '<h3 class="plan-title">WELCOME</h3><p class="plan-title">'.$name.'</br>WHAT DO YOU WANT TO DO TODAY
		   </p> 
			';

			 echo'<p class="plan-title"><a class="button large" href="videos.php">RENT</a>
		   </p>  
			 ' ;
			 echo '<p class="plan-title"><a class="button large" href="person.php">CHECK STATUS</a>
		   </p>  
			 ';
		}
		else{
            echo '<p class="plan-title">WRONG PASSWORD</br>TRY AGAIN
            <p class="plan-title"><a class="button large" href="login.php">BACK</a></br>
			</p>';
		}
	  }
	  $conn->close();
	  }
	  
	
	?>

						
					    </p>
					  </div>
				  </div>            	                 
				</div> 
			 <div class="bgrid animate-this">               
				 </div> 	           
		   </div> 
		</div> 
	   </section> 
	   <?php include "foot.php"?>
   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>
</body>
</html>
<?php
}
?>