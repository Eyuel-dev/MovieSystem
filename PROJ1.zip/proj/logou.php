<?php
require("start.php");
session_destroy();
header("Location: home.php");
?>