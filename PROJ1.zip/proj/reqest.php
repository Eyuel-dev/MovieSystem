<?php
include "link.php";
require("start.php");
?>
<html>
<head>
<title>REQEST</title>

<link rel="stylesheet" href="css/basee.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/screen.css">
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />
<link rel="icon" href="images/fpic.jpg">


</head>
<body>
<div class="container">
  <div class="blankSeparator"></div>
  <div class="one_third contactsidebar">
    <section class="first">
      <h3>OUR LOCATION</h3>
      <div class="boxtwosep"></div>
      <ul class="contactsidebarList">
        <li>Location:GERJI,A.A ,ETHIOPIA</li>
        <li>Phone:+251927429713</li>
        <li>Website: <a href="#" title="">http://VideoRental.com</a></li>
        <li>Email: <a href="#" title="">Project@gmail.com</a></li>
      </ul>
    </section>
    <section class="third">
      <h3>Latest Offers</h3>
      <div class="boxtwosep"></div>
      <p>Special Request for free</p>
</br><a href='home.php' > <h3 align="center">HOME</h3></a>
    </section>
  </div>
  <div class="two_third lastcolumn contact1">
    <div id="contactForm">
      <h2>Leave Your Request</h2>
      <div class="sepContainer"></div>

      <form action="hello.php" method="post" id="contact_form">
       <?php
       if(!isset($_SESSION['username'])){
       echo' <div class="name">
          <label for="name">CellPhone Number:</label>
          <p> Please enter your CellPhone Number</p>
          <input id=name name="cellno" type=text placeholder="+2519--------" required />
        </div>
        <div class="email">
          <label for="email">Your Email:</label>
          <p> Please enter your email address</p>
          <input id=email name="email" type=email placeholder="example@domain.com" required />
        </div>';
       }
       if(isset($_SESSION['username'])){
         $id=$_SESSION['username'];
        $query = "SELECT * from member_user  where m_username='$id'";
        $query_res = mysqli_query($con,$query);
        
        while($data = mysqli_fetch_assoc($query_res)){
          $cell = $data["m_cellphone"];
          $mail=$data["m_email"];
        }
         echo'
        <input id=name name="cellno" type=hidden value='.$cell.' />
        <input id=name name="email" type=hidden value='.$mail.' />
        ';
       }
        ?>
        <div class="message">
          <label for="message">Your Request:</label>
          <p> Please enter your Request</p>
          <textarea id=message name="message" rows=6 cols=10 required></textarea>
        </div>
        <div>
          <input type="submit" value="Submit" name="submit"/>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="blankSeparator2"></div>
<div>
</div>



<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script> 
<script src="js/screen.js" type="text/javascript"></script> 
<script src="js/poshytip-1.0/src/jquery.poshytip.min.js" type="text/javascript"></script> 
<script src="js/tabs.js" type="text/javascript"></script> 
<script src="js/jquery.tweetable.js" type="text/javascript"></script> 
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<script src="js/superfish.js" type="text/javascript"></script> 
<script src="js/hoverIntent.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>
</body>
</html>