<?php 

require("start.php");
if(isset($_SESSION['username'])){
    header("Location: videos.php");
}else{
    


$email = "";
$pass = "";
?>

<head>
  <title>REGESTRATION</title>

   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css">    

	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>

	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
	
   <header class="main-header">
   	
   	<div class="logo">
	      <a href="home.php">Elevate</a>
	   </div> 

	   <a class="menu-toggle" href="#"><span>Menu</span></a>   	

   </header>

   <nav id="menu-nav-wrap">

        <h3>Navigation</h3>   	
         <ul class="nav-list">
             <li><a href="home.php" title="">Home</a></li>
             <li><a href="register.php" title="">Register</a></li>
			 <li><a href="login.php" title="">Login</a></li>
			 <li><a href="videos.php" title="">Explore</a></li>	
			 <li><a href="reqest.php" title="">Reqest</a></li>	
			 <li><a href="person.php" title="">Account Information</a></li>		
         </ul>
     </nav> 
		<section id="pricing">

	   	<div class="row section-intro animate-this">
	   		<div class="col-twelve with-bottom-line">

	   			<h2>REGESTRATION</h2>

	   		</div>   		
		   </div>
		   

		 <div class="row pricing-content">

		   <div class="pricing-tables block-1-3  group">

			  <div class="bgrid animate-this"> 
			
						  
				 </div> 

			  <div class="bgrid animate-this">

				  <div class="price-block">

					  <div class="top-part">

						  <h3 class="plan-title"></h3>
												  

					  </div>               

					 <div class="bottom-part">
	                  
													  
							
						 </ul>


<p class="plan-title">
<?php 
if(isset($_POST['submit'])){
    $us=$_POST['uname'];
    $pw=$_POST['pword'];
    $fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$kk=$_POST['kk'];
	$w=$_POST['woreda'];
	$hn=$_POST['hno'];
	$em=$_POST['email'];
	$cn=$_POST['cellno'];
	$bal=$_POST['bal'];
 $conn = new mysqli("localhost", "root", "","project");
 $sql="insert into member_user(m_username, m_password, m_fname, m_lname, m_kk, m_woreda, m_hno, m_email, m_cellphone, m_balance) values('$us','$pw','$fname','$lname',2,'$w','$hn','$em','$cn','$bal')";
 if ($conn->query($sql) === TRUE) {
    echo "REGISTERED</br> THANK YOU ".$fname." FOR JOINING US";
    echo'
        <p class="plan-title"><a class="button large" href="home.php">home</a></br></p>';

}
 else {
    echo "SORRY ERROR HAS OCCUED CHECK YOUR INPUT AND TRY AGAIN";
    echo'
        <p class="plan-title"><a class="button large" href="home.php">HOME</a></br></p>';
}
}
?>		

						
						</p>
					  </div>
					  
				  </div>            	                 

				</div> 

			 <div class="bgrid animate-this">               

											   

				 </div> 	           

		   </div> 

		</div> 
		
		  
	   </section> 
	   <?php include "foot.php"?>
   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>

<?php
}
?>