<?php include "link.php";
require("start.php");
?>

<head>
	<title>RENT CONFERMATION</title>

   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css">    
	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>
	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
   <header class="main-header">
   </header>
		<section id="pricing">


	   	<div class="row pricing-content">

	         <div class="pricing-tables block-1-3  group">

	            <div class="bgrid animate-this"> 
      
				   </div> 

	            <div class="bgrid animate-this">

	            	<div class="price-block">

	            		
                          <?php
                          $date=date("Y/m/d");
                          $id=isset($_POST['ids']) ? $_POST['ids'] : "";
                          echo'
                          <div class="top-part">
                    <h3>RENT CONFERMATION</h3>							
                </div>';
                if(isset($_SESSION['username'])){
                    $sum=0;
                    $userr=$_SESSION['username'];
                    $query = "select * from member_user where m_username='$userr' ";
                    $query_res = mysqli_query($con,$query);
                     $data=mysqli_fetch_assoc($query_res);
                     $bal=$data['m_balance'];
                                
                    if($id==""){
                        echo'<p class="plan-title">No Rented Movies Please Rent Some Movies</p>';
                    }
                
                if($id!=""){
                    foreach($id as $val){
                        $query = "select * from video where v_id='$val' ";
                        $query_res = mysqli_query($con,$query);
                        $data=mysqli_fetch_assoc($query_res);
                        $sum=$sum+$data['v_price'];
                    }
                    $rrr=$bal-$sum;
                    if($sum<=$bal){
                    foreach($id as $val){
                        $query = "select * from video where v_id='$val' ";
                        $query_res = mysqli_query($con,$query);
                        $data=mysqli_fetch_assoc($query_res);
                        $queryy = "select * from copy where v_id='$val' and c_status='n_rented' ";
                        $query_res1 = mysqli_query($con,$queryy);
                        $data1=mysqli_fetch_assoc($query_res1);
                        $cid=$data1['c_id'];
                        if($data1==""){
                            echo" Sorry All Copies Of ".$data['v_name']." Are Rented</br>";
                        }
                        
                        if($data1!=""){
                            
                            
                           echo $data['v_name'].".........".$data['v_price']." Birr</br>";
                    }
                
                
                        $sqll = "UPDATE member_user SET m_balance='$rrr' WHERE m_username='$userr'";
                        mysqli_query($con, $sqll);
                        $sqll = "UPDATE copy SET c_status='rented',c_rby='$userr', c_renteddate='$date' WHERE c_id='$cid'";
                        mysqli_query($con, $sqll);

                }
                if($sum<=$bal&&$data1!=""){
                    echo"</br>Total Payment=".$sum." Birr</br>";
                echo'<p class="plan-title">Rented Enjoy.</p>';
                }
            }
        }
        if($sum>$bal){
            echo'<p class="plan-title">!Insiffcent Balance!</p>';
        }
        
            echo '<a class="button large" href="home.php">HOME</a>';
        }



                if(!isset($_SESSION['username'])){
                    if($id==""){
                        echo'<p class="plan-title">No Rented Movies Please Rent Some Movie</p>';
                        echo '<a class="button large" href="videos.php">RENT</a>';
                    
                    }

                        if($id!=""){
                            $sum=0;
                            $idd=rand(10000,99999);
                            foreach($id as $val){
                                $query = "select * from video where v_id='$val' ";
                                $query_res = mysqli_query($con,$query);
                                $data=mysqli_fetch_assoc($query_res);
                                $queryy = "select * from copy where v_id='$val' and c_status='n_rented' ";
                        $query_res1 = mysqli_query($con,$queryy);
                        $data1=mysqli_fetch_assoc($query_res1);
                        $cid=$data1['c_id'];
                        if($data1==""){
                            echo" Sorry All Copies Of ".$data['v_name']." Are Rented</br>";
                           
                        }
                        if($data1){
                                   echo $data['v_name'].".........".$data['v_price']." Birr</br>";
                                  $sum=$sum+$data['v_price'];
                                 
                                
                                 
                                 $nmq="insert into nm_user (`n_id`, `n_payment`) values('$idd','$sum')";
                                  mysqli_query($con,$nmq);
                                  $sqll = "UPDATE copy SET c_status='rented',c_rbynm='$idd',c_renteddate='$date' WHERE c_id='$cid'";
                                  mysqli_query($con, $sqll);
                                         
                        }
                        
                    }

                    if($data){
                        $new="update nm_user set n_payment='$sum' where n_id='$idd'";
                        mysqli_query($con,$new);
                        echo"</br>Total Payment=".$sum." Birr</br>";
                        echo '<p class="price-month">Coupon Number='.$idd.'</p>';
                    }
                }
                echo '<a class="button large" href="home.php">HOME</a>';
                    
            }
                          ?>             

	            		
	            	</div>            	                 

				  </div> 

	         </div> 

	      </div>

	   </section> 


	  <?php include "foot.php";?>

   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>