<html>

 <head>
	<title>HOME</title>

   
	<link rel="stylesheet" href="css/img.css"> 
   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css"> 

   <style type="text/css" media="screen">
   	#styles { 
   		background: white;
   		padding-top: 12rem;
   		padding-bottom: 12rem;
   	}      	
   </style>    

	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>

	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
   <header class="main-header">
   	
   	<div class="logo">
	      <a href="home.php">MOVIES</a>
	   </div> 

	   <a class="menu-toggle" href="home.php"><span>Menu</span></a>   	

   </header>

   <nav id="menu-nav-wrap">

   	<h3>Navigation</h3>   	
		<ul class="nav-list">
			<li><a href="home.php" title="">Home</a></li>
			<li><a href="register.php" title="">Register</a></li>
			<li><a href="login.php" title="">Login</a></li>
			<li><a href="videos.php" title="">Explore</a></li>
			<li><a href="reqest.php" title="">Reqest</a></li>	
			<li><a href="person.php" title="">Account Information</a></li>		
		</ul>
	</nav> 

   <div id="main-content-wrap">

   	<section id="intro">
		   
		   <div class="row intro-content">
		   	<div class="col-twelve">

		   		<h3 class="animate-intro">WELCOME TO OUR WEBSITE</h3>
			  		
					<h1 class="animate-intro">
						The Perfect Place To Rent The Best Movies
					</h1>	
					
					<div class="animate-intro">
					
				   <ul class="button large">
					   <a href="videos.php">EXPLORE | </a>
					   <?php
					   require("start.php");
					 if(isset($_SESSION['username'])){
						echo "YOU ARE LOGED IN<a href='logou.php'> | LOGOUT</a>";}
					 else{
					 echo "<a href='login.php'> | LOGIN</a>";}
					   ?>
				   </ul>
			   </div>		 			
			   <img src="images/home.png" alt="" class="animate-intro" id="homeimage"> 
			</div> 		   			
		</div>
	</section>
</div> 
  <?php include "foot.php"?>
   
   <div id="go-top">
		<a class="smoothscroll" title="Back to Top" href="#top"><i class="fa fa-long-arrow-up"></i></a>
	</div>

   <div id="preloader"> 
    	<div id="loader"></div>
   </div> 
   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>