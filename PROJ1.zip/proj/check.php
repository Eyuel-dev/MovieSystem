<?php
require("start.php");
if(isset($_SESSION['username'])){
    echo $_SESSION['username'];
}else{
    
}
?>