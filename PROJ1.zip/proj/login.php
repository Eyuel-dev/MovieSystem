<?php 
require("start.php");
if(isset($_SESSION['username'])){
    header("Location: home.php");
}else{
$email = "";
$pass = "";
?>
<html>
<head>
  <title>LOGIN</title>

   <link rel="stylesheet" href="css/base.css"> 
   <link rel="stylesheet" href="css/vendor.css"> 
   <link rel="stylesheet" href="css/main.css">    

	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>

	<link rel="icon" type="image/png" href="images/fpic.jpg">

</head>

<body id="top">
	
   <header class="main-header">
   	
   	<div class="logo">
	      <a href="home.php">Elevate</a>
	   </div> 

	   <a class="menu-toggle" href="home.php"><span>Menu</span></a>   	

   </header>

   <nav id="menu-nav-wrap">

        <h3>Navigation</h3>   	
         <ul class="nav-list">
             <li><a href="home.php" title="">Home</a></li>
             <li><a href="register.php" title="">Register</a></li>
			 <li><a href="login.php" title="">Login</a></li>
			 <li><a href="videos.php" title="">Explore</a></li>	
			 <li><a href="reqest.php" title="">Reqest</a></li>	
			 <li><a href="person.php" title="">Account Information</a></li>		
         </ul>
    </nav> 
		<section id="pricing">

	   	<div class="row section-intro animate-this">
	   		<div class="col-twelve with-bottom-line">

	   			<h2>LOGIN</h2>

	   		</div>   		
		   </div>
		   
		 <form action="welcome.php" method="POST">
		 <div class="row pricing-content">

		   <div class="pricing-tables block-1-3  group">

			  <div class="bgrid animate-this"> 
			
						  
				 </div> 

			  <div class="bgrid animate-this">

				  <div class="price-block">

					  <div class="top-part">

						  <h3 class="plan-title">LOGIN FORM</h3>
												  

					  </div>               

					 <div class="bottom-part">

						  <ul class="features">
							<li><input type="text"  placeholder="USERNAME" name="uname" ></li>
							<li><input type="text"  placeholder="PASSWORD" name="pword" ></li>		                  
													  
							
						 </ul>

						<input type="submit" class="button large" value="login" name="submit">
						<a class="button large" href="login.php">clear</a>

						<a class="button large" href="register.php">register</a>


					  </div>
					  
				  </div>            	                 

				</div> 

			 <div class="bgrid animate-this">               

											   

				 </div> 	           

		   </div> 

		</div> 
	 </form>
		
		  
	   </section> 
	   <?php include "foot.php"?>
   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>

<?php
}
?>